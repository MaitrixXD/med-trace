// MED-TRACE Service Worker for Offline Caching and Android App Installation
const CACHE_NAME = 'med-trace-v1';
const ASSETS_TO_CACHE = [
  './',
  './Med Trace.html',
  './style.css',
  './features.css',
  './script.js',
  './features.js',
  './pharmacy.js',
  './reminders.js',
  './logo.jpg',
  './icon-192.png',
  './icon-512.png',
  './hero.jpg',
  './doctor_a.jpg',
  './doctor_b.jpg',
  './manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn('Cache addAll warning:', err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return (
        cachedResponse ||
        fetch(event.request).then((networkResponse) => {
          return networkResponse;
        }).catch(() => {
          return caches.match('./Med Trace.html');
        })
      );
    })
  );
});
